<template>
  <div>


    <router-link to="/category/1001"> sd</router-link>
  </div>
</template>

<script>
export default {
  name: "Home",
};
</script>
