<template>
  <div class="ishtari-loader">
    <div></div>
    <div></div>
  </div>
</template>
<script>
export default {};
</script>