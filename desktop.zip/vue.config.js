module.exports = {
  productionSourceMap: false,
  parallel: false
}